package com.example.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        val context = applicationContext
        val text: CharSequence = "secondonStart"
        val duration = Toast.LENGTH_SHORT
        val toast = Toast.makeText(context, text, duration)
        toast.show()
    }

    override fun onStart() {
        super.onStart()
        val context = applicationContext
        val text: CharSequence = "secondonStart"
        val duration = Toast.LENGTH_SHORT
        val toast = Toast.makeText(context, text, duration)
        toast.show()
    }

    override fun onResume() {
        super.onResume()
        val context = applicationContext
        val text: CharSequence = "secondonResume"
        val duration = Toast.LENGTH_SHORT
        val toast = Toast.makeText(context, text, duration)
        toast.show()
    }

    override fun onPause() {
        super.onPause()
        val context = applicationContext
        val text: CharSequence = "secondonPause"
        val duration = Toast.LENGTH_SHORT
        val toast = Toast.makeText(context, text, duration)
        toast.show()
    }

    override fun onStop() {
        super.onStop()
        val context = applicationContext
        val text: CharSequence = "secondonStop"
        val duration = Toast.LENGTH_SHORT
        val toast = Toast.makeText(context, text, duration)
        toast.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        val context = applicationContext
        val text: CharSequence = "secondonDestroy"
        val duration = Toast.LENGTH_SHORT
        val toast = Toast.makeText(context, text, duration)
        toast.show()
    }
}
